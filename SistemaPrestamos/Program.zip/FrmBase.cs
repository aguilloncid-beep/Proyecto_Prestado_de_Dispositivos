﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaPresatamos
{
    public partial class FrmBase : Form
    {
        public FrmBase()
        {
            InitializeComponent();
        }
    }
}
